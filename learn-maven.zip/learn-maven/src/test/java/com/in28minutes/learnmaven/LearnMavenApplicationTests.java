package com.in28minutes.learnmaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
